class Vote < ApplicationRecord
	belongs_to :topic
end
